#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
	hello();
	exitS(1);
	return 0;	
}
